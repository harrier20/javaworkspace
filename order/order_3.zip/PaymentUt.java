package order;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PaymentUt {

	String url = "jdbc:mysql://localhost:3306/doncha?characterEncoding=UTF-8";
	String user = "root";
	String pass = "1234";

	Connection con = null;
	ResultSet rs = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;

	OrderList ol = new OrderList();

	// 들어온 주문자의 휴대폰 번호 check
	public boolean checkMember(String phone_number) {
		boolean flag = true;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			stmt = con.createStatement();
			System.out.println("맴버 체크 시작");

			String sql = "select * from member where phone_number = " + phone_number;

			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				String pn = rs.getString("phone_number");
				System.out.println("rs = " + pn);
				flag = true;
			} else {// 회원이 없는경우
				System.out.println("회원이 아니네??");
				flag = false;
			}

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(flag);
		return flag;
	}

	// 맴버 추가하는 메서드
	public void joinMember(String phone_number) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			stmt = con.createStatement();
			System.out.println("맴버 추가 시작");
			System.out.println(phone_number);
			String sql = "insert into member (phone_number) values ('" + phone_number + "')";

			stmt.executeUpdate(sql);

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 들어온 주문을 order_history로 보내는 메서드
	public void orderConfirm(String phone_number) throws SQLException {
		
		PointUt pt = new PointUt();
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			System.out.println("드라이버 로드 성공!!");

			String sql = "insert into order_history(product_id, product_name, phone_number, order_count, order_price, revenue)";
			sql += " values(?,?,?,?,?,?)";

			pstmt = con.prepareStatement(sql);
			// 바인드 변수값 처리
			pstmt.setInt(1, ol.getProduct_id());
			pstmt.setString(2, ol.getProduct_name());// 상품명
			pstmt.setString(3, phone_number); // 폰번
			pstmt.setInt(4, ol.getOrder_count());// 수량
			pstmt.setInt(5, ol.getOrder_price());// 가격
			pstmt.setInt(6, ol.getRevenue());
			
			pt.pointPlus(phone_number, ol.getRevenue());//포인트 적립

			// 쿼리실행(DML)
			int result = pstmt.executeUpdate();
			if (result == 1) {
				System.err.println("성공");

			} else {
				System.out.println("실패");
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			con.close();
		}

	}


}