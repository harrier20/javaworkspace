package order;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class PaymentUt {

	String url = "jdbc:mysql://localhost:3306/doncha";
	String user = "root";
	String pass = "1234";

	Connection con = null;
	ResultSet rs = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	
	OrderList ol = new OrderList();
	
	//들어온 주문자의 휴대폰 번호 check
	public void checkMember(String phone_number){

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			stmt = con.createStatement();
			System.out.println("맴버체크시작");
			String sql = "select " + phone_number+" from member where phone_number";
	
			rs=stmt.executeQuery(sql);
			
			if(rs.next()) {
				String pn = rs.getString(phone_number);
			}else {
				
			};
			
			
			System.out.println("rs = "+rs.getString(phone_number));
	}catch (SQLException | ClassNotFoundException e) {
		e.printStackTrace();
	} finally {
		if(rs !=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	}
	
	
	
	
	//들어온 주문을 order_history로 보내는 메서드
	public void orderConfirm(String phone_number) throws SQLException{
		

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			System.out.println("드라이버 로드 성공!!");

			String sql = "insert into order_history(product_id, product_name, phone_number, order_count, order_price, revenue)";
			sql += " values(?,?,?,?,?,?)";

			pstmt = con.prepareStatement(sql);
			// 바인드 변수값 처리
			pstmt.setInt(1, ol.getProduct_id());
			pstmt.setString(2, ol.getProduct_name());// 상품명
			pstmt.setString(3, phone_number); // 폰번
			pstmt.setInt(4, ol.getOrder_count());// 수량
			pstmt.setInt(5, ol.getOrder_price());// 가격
			pstmt.setInt(6, ol.getRevenue());


			// 쿼리실행(DML)
			int result = pstmt.executeUpdate();
			if (result == 1) {
				System.err.println("성공");
				
			} else {
				System.out.println("실패");
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			con.close();
		}

	}
	
//	
//	public void pointPlus(String phone_num,double revenue) throws SQLException {
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//			con = DriverManager.getConnection(url, user, pass);
//			System.out.println("드라이버 로드 성공!!");
//
//			String sql = "update member set point=?  phone_num=?";
//			pstmt = con.prepareStatement(sql);
//			revenue = 1.1*revenue;
//			pstmt.setDouble(1,revenue);
//			pstmt.setString(2, phone_num);// 상품명
//			
//		} catch (SQLException | ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();			
//		}finally {
//			con.close();
//		}
//				
//	}
	
	
}