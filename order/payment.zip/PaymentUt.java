package order;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PaymentUt {

	String url = "jdbc:mysql://localhost:3306/doncha";
	String user = "root";
	String pass = "1234";

	Connection con = null;
	ResultSet rs = null;
	PreparedStatement pstmt = null;
	
	
	OrderList ol = new OrderList();
	
	
	//들어온 주문을 order_history로 보내는 메서드
	public void orderConfirm() throws SQLException{
		

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			System.out.println("드라이버 로드 성공!!");

			String sql = "insert into order_history(product_id, product_name, phone_number, order_count, order_price, revenue)";
			sql += " values(?,?,?,?,?,?)";

			pstmt = con.prepareStatement(sql);
			// 바인드 변수값 처리
			pstmt.setInt(1, ol.getProduct_id());
			pstmt.setString(2, ol.getProduct_name());// 상품명
			pstmt.setString(3, ol.getPhone_number()); // 폰번
			pstmt.setInt(4, ol.getOrder_count());// 수량
			pstmt.setInt(5, ol.getOrder_price());// 가격
			pstmt.setInt(6, ol.getRevenue());

			// 쿼리실행(DML)
			int result = pstmt.executeUpdate();
			if (result == 1) {
				System.err.println("성공");
			} else {
				System.out.println("실패");
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			con.close();
		}

	}
	
	
}